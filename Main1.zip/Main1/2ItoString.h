#pragma once
#include <string>
using namespace std;

class ToString{
        
     public:
        virtual string toString() = 0; //Método virtual puro o abstracto 
};